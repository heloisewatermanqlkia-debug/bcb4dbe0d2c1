// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Linear-scan allocate"); }
int main(){
  announce();
  return lionss_run_workload("regalloclinear");
}
