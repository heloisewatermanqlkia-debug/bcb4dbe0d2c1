// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Insert deopt guards\n", stdout);
  return lionss_run_workload("deopt-guard");
}
