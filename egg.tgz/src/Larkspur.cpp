// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Render larkspur bloom"); }
int main(){
  announce();
  return lionss_run_workload("Larkspur");
}
