# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(svdrandomized src/svdrandomized.cpp)
set_property(TARGET svdrandomized PROPERTY CXX_STANDARD 11)
target_link_libraries(svdrandomized lionss pthread)

add_executable(wireguard_key src/wireguard_key.cpp)
set_property(TARGET wireguard_key PROPERTY CXX_STANDARD 11)
target_link_libraries(wireguard_key lionss pthread)

add_executable(dedupeBlock src/dedupeBlock.cpp)
set_property(TARGET dedupeBlock PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupeBlock lionss pthread)

add_executable(TmuxPane src/TmuxPane.cpp)
set_property(TARGET TmuxPane PROPERTY CXX_STANDARD 11)
target_link_libraries(TmuxPane lionss pthread)

add_executable(mermaid_render src/mermaid_render.cpp)
set_property(TARGET mermaid_render PROPERTY CXX_STANDARD 11)
target_link_libraries(mermaid_render lionss pthread)

add_executable(decal-atlas src/decal-atlas.cpp)
set_property(TARGET decal-atlas PROPERTY CXX_STANDARD 11)
target_link_libraries(decal-atlas lionss pthread)

add_executable(notebookExec src/notebookExec.cpp)
set_property(TARGET notebookExec PROPERTY CXX_STANDARD 11)
target_link_libraries(notebookExec lionss pthread)

add_executable(ql-planner src/ql-planner.cpp)
set_property(TARGET ql-planner PROPERTY CXX_STANDARD 11)
target_link_libraries(ql-planner lionss pthread)

add_executable(wasi-preopen src/wasi-preopen.cpp)
set_property(TARGET wasi-preopen PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-preopen lionss pthread)

add_executable(deopt-guard src/deopt-guard.cpp)
set_property(TARGET deopt-guard PROPERTY CXX_STANDARD 11)
target_link_libraries(deopt-guard lionss pthread)

add_executable(fzf-preview src/fzf-preview.cpp)
set_property(TARGET fzf-preview PROPERTY CXX_STANDARD 11)
target_link_libraries(fzf-preview lionss pthread)

add_executable(trustRegion src/trustRegion.cpp)
set_property(TARGET trustRegion PROPERTY CXX_STANDARD 11)
target_link_libraries(trustRegion lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(selinux-relabel src/selinux-relabel.cpp)
set_property(TARGET selinux-relabel PROPERTY CXX_STANDARD 11)
target_link_libraries(selinux-relabel lionss pthread)

add_executable(GiProbeBake src/GiProbeBake.cpp)
set_property(TARGET GiProbeBake PROPERTY CXX_STANDARD 11)
target_link_libraries(GiProbeBake lionss pthread)

add_executable(TcpCubic src/TcpCubic.cpp)
set_property(TARGET TcpCubic PROPERTY CXX_STANDARD 11)
target_link_libraries(TcpCubic lionss pthread)

add_executable(onyxShard src/onyxShard.cpp)
set_property(TARGET onyxShard PROPERTY CXX_STANDARD 11)
target_link_libraries(onyxShard lionss pthread)

add_executable(Larkspur src/Larkspur.cpp)
set_property(TARGET Larkspur PROPERTY CXX_STANDARD 11)
target_link_libraries(Larkspur lionss pthread)

add_executable(verdigris src/verdigris.cpp)
set_property(TARGET verdigris PROPERTY CXX_STANDARD 11)
target_link_libraries(verdigris lionss pthread)

add_executable(gmres_restart src/gmres_restart.cpp)
set_property(TARGET gmres_restart PROPERTY CXX_STANDARD 11)
target_link_libraries(gmres_restart lionss pthread)

add_executable(pg_reindex src/pg_reindex.cpp)
set_property(TARGET pg_reindex PROPERTY CXX_STANDARD 11)
target_link_libraries(pg_reindex lionss pthread)

add_executable(ResnetProbe src/ResnetProbe.cpp)
set_property(TARGET ResnetProbe PROPERTY CXX_STANDARD 11)
target_link_libraries(ResnetProbe lionss pthread)

add_executable(aftermathDump src/aftermathDump.cpp)
set_property(TARGET aftermathDump PROPERTY CXX_STANDARD 11)
target_link_libraries(aftermathDump lionss pthread)

add_executable(regalloclinear src/regalloclinear.cpp)
set_property(TARGET regalloclinear PROPERTY CXX_STANDARD 11)
target_link_libraries(regalloclinear lionss pthread)

add_executable(labelSmooth src/labelSmooth.cpp)
set_property(TARGET labelSmooth PROPERTY CXX_STANDARD 11)
target_link_libraries(labelSmooth lionss pthread)

add_executable(relooperCfg src/relooperCfg.cpp)
set_property(TARGET relooperCfg PROPERTY CXX_STANDARD 11)
target_link_libraries(relooperCfg lionss pthread)

add_executable(thread-border src/thread-border.cpp)
set_property(TARGET thread-border PROPERTY CXX_STANDARD 11)
target_link_libraries(thread-border lionss pthread)

add_executable(VmallocStress src/VmallocStress.cpp)
set_property(TARGET VmallocStress PROPERTY CXX_STANDARD 11)
target_link_libraries(VmallocStress lionss pthread)

add_executable(mux9 src/mux9.cpp)
set_property(TARGET mux9 PROPERTY CXX_STANDARD 11)
target_link_libraries(mux9 lionss pthread)

add_executable(snippetCompile src/snippetCompile.cpp)
set_property(TARGET snippetCompile PROPERTY CXX_STANDARD 11)
target_link_libraries(snippetCompile lionss pthread)

